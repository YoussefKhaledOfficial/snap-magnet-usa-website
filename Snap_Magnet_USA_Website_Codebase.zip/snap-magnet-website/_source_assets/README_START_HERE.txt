Snap Magnet USA - Claude Asset Kit

This ZIP contains brand assets, packaging images, filled business/product/legal text files, pricing recommendations, and instructions for building the Snap Magnet USA website.

How to use:
1. Review every TXT file.
2. Replace any "Not provided yet" or [Add launch date] placeholders.
3. Add final product photos, AI renders, and hero videos when ready.
4. Upload this entire ZIP to Claude with the website build script.
5. Tell Claude to use the files as website source material.

Important:
- Legal pages are draft placeholders and should be reviewed before launch.
- Pricing is recommended based on competitor research and premium positioning; confirm production cost before accepting orders.
- Do not claim "Made in USA" unless legally verified.
- Do not mention Egypt or the previous branch on the website.

Primary contact info included:
Email: snapmagnetusa@gmail.com
Phone: (773) 851-2030
Instagram: https://www.instagram.com/snapmagnet.usa/
