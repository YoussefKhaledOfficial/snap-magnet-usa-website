import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        ivory: "#F4F0E9",
        cream: "#F8F6F1",
        espresso: "#382010",
        ink: "#2B1A10",
        stone: "#B0A898",
        mist: "#D8D0C8",
        champagne: "#B8946A"
      },
      boxShadow: {
        soft: "0 28px 80px rgba(43, 26, 16, 0.10)",
        card: "0 18px 45px rgba(43, 26, 16, 0.08)"
      },
      borderRadius: {
        xl2: "1.35rem",
        xl3: "2rem"
      },
      fontFamily: {
        heading: ["Cormorant Garamond", "Georgia", "serif"],
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        accent: ["Caveat", "Segoe Print", "cursive"]
      }
    }
  },
  plugins: []
};

export default config;
