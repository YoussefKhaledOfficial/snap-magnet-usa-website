"use client";

import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { QuoteRequestInput, quoteRequestSchema } from "@/lib/validators";
import { getUtmParams, trackGenerateLead, trackQuoteFormStart } from "@/lib/tracking";

export default function QuoteForm() {
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [message, setMessage] = useState("");
  const started = useRef(false);
  const form = useForm<QuoteRequestInput>({
    resolver: zodResolver(quoteRequestSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      company: "",
      eventType: "",
      eventDate: "",
      cityState: "",
      quantityRange: "100-250",
      needsDesignHelp: false,
      message: "",
      ...getUtmParams()
    }
  });

  function markStarted() {
    if (!started.current) {
      started.current = true;
      trackQuoteFormStart();
    }
  }

  async function onSubmit(values: QuoteRequestInput) {
    setStatus("idle");
    setMessage("");
    const response = await fetch("/api/quote", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...values, ...getUtmParams() })
    });
    const data = await response.json();
    if (!response.ok) {
      setStatus("error");
      setMessage(data.error || "Could not submit quote request. Please email us directly.");
      return;
    }
    setStatus("success");
    setMessage("Your quote request was received. We’ll review the details and follow up soon.");
    trackGenerateLead({ quantityRange: values.quantityRange, eventType: values.eventType });
    form.reset({ ...form.getValues(), fullName: "", email: "", phone: "", company: "", eventType: "", eventDate: "", cityState: "", message: "" });
  }

  return (
    <form onFocus={markStarted} onSubmit={form.handleSubmit(onSubmit)} className="card grid gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="fullName">Full name</label>
          <input id="fullName" className="input" {...form.register("fullName")} />
          {form.formState.errors.fullName && <p className="mt-2 text-xs font-bold text-red-700">{form.formState.errors.fullName.message}</p>}
        </div>
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" className="input" type="email" {...form.register("email")} />
          {form.formState.errors.email && <p className="mt-2 text-xs font-bold text-red-700">{form.formState.errors.email.message}</p>}
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="phone">Phone optional</label>
          <input id="phone" className="input" {...form.register("phone")} />
        </div>
        <div>
          <label className="label" htmlFor="company">Company optional</label>
          <input id="company" className="input" {...form.register("company")} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="eventType">Event or project type</label>
          <select id="eventType" className="input" {...form.register("eventType")}> 
            <option value="">Select one</option>
            <option>Wedding / Engagement</option>
            <option>Graduation</option>
            <option>Birthday / Baby Shower</option>
            <option>Expo / Trade Show</option>
            <option>Business Giveaway</option>
            <option>QR Code Campaign</option>
            <option>Other</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="eventDate">Event date optional</label>
          <input id="eventDate" className="input" type="date" {...form.register("eventDate")} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="cityState">City / state</label>
          <input id="cityState" className="input" placeholder="Chicago, IL" {...form.register("cityState")} />
        </div>
        <div>
          <label className="label" htmlFor="quantityRange">Quantity range</label>
          <select id="quantityRange" className="input" {...form.register("quantityRange")}> 
            <option>50-100</option>
            <option>100-250</option>
            <option>250-500</option>
            <option>500-1,000</option>
            <option>1,000+</option>
          </select>
        </div>
      </div>
      <label className="flex items-center gap-3 rounded-2xl border border-espresso/10 bg-white/60 px-4 py-3 text-sm font-semibold text-ink/70">
        <input type="checkbox" {...form.register("needsDesignHelp")} />
        I may need design or layout help.
      </label>
      <div>
        <label className="label" htmlFor="message">Project details</label>
        <textarea id="message" className="input min-h-36" placeholder="Tell us about the event, design, deadline, and what you want the magnets to include." {...form.register("message")} />
      </div>
      {status !== "idle" && <p className={`rounded-2xl p-4 text-sm font-semibold ${status === "success" ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}>{message}</p>}
      <button type="submit" className="btn-primary py-4" disabled={form.formState.isSubmitting}>{form.formState.isSubmitting ? "Submitting..." : "Request Pricing"}</button>
      <p className="text-xs leading-6 text-ink/45">For order questions, email snapmagnetusa@gmail.com or call (773) 851-2030.</p>
    </form>
  );
}
