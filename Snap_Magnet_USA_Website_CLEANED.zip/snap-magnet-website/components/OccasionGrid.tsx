const occasions = ["Weddings & engagements", "Graduations", "Baby showers", "Birthdays", "Family gifts", "Corporate events", "Expos & giveaways", "QR code campaigns"];

export default function OccasionGrid() {
  return (
    <section className="section bg-espresso text-cream">
      <div className="container-page">
        <div className="max-w-3xl">
          <p className="eyebrow text-champagne">Occasions</p>
          <h2 className="font-heading text-4xl font-semibold leading-tight tracking-[-0.035em] sm:text-5xl">One product, many reasons to be remembered.</h2>
        </div>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {occasions.map((item) => (
            <div key={item} className="rounded-[1.5rem] border border-cream/12 bg-cream/8 p-5 text-sm font-bold text-cream/88 backdrop-blur">
              <span className="mr-2 text-champagne">✦</span>{item}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
