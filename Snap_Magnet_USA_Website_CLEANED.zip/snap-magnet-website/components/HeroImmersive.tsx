"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { useState } from "react";

function FloatingMagnets() {
  const cards = [
    "Weddings", "Graduations", "QR Giveaways", "Family Gifts", "Events", "Brand Moments"
  ];
  return (
    <div className="absolute inset-0 overflow-hidden rounded-[2.5rem] bg-[radial-gradient(circle_at_30%_20%,rgba(248,246,241,0.95),transparent_30%),linear-gradient(135deg,rgba(56,32,16,0.08),rgba(184,148,106,0.18))]">
      <div className="absolute left-1/2 top-1/2 h-[440px] w-[440px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-champagne/15 blur-3xl" />
      {cards.map((label, index) => (
        <motion.div
          key={label}
          className="magnet-frame absolute grid h-36 w-36 place-items-center rounded-[2rem] bg-cream/95 p-5 text-center shadow-soft"
          initial={false}
          animate={{
            x: [0, index % 2 ? 18 : -18, 0],
            y: [0, index % 2 ? -12 : 16, 0],
            rotate: [index * 3 - 8, index * 3 + 4, index * 3 - 8]
          }}
          transition={{ duration: 6 + index, repeat: Infinity, ease: "easeInOut" }}
          style={{
            left: `${10 + (index * 13) % 70}%`,
            top: `${12 + (index * 17) % 68}%`
          }}
        >
          <span className="font-heading text-2xl font-semibold leading-none text-espresso">{label}</span>
          <span className="mt-2 block text-[10px] font-bold uppercase tracking-[0.22em] text-champagne">Snap Magnet</span>
        </motion.div>
      ))}
      <motion.div
        className="magnet-frame absolute left-1/2 top-1/2 grid h-64 w-64 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-[2.5rem] bg-cream p-8 text-center"
        animate={{ rotateY: [0, 8, 0], rotateX: [0, -6, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      >
        <div>
          <p className="font-accent text-2xl text-champagne">pick me up</p>
          <p className="font-heading text-5xl font-semibold leading-none text-espresso">Photo Magnet</p>
          <p className="mt-3 text-sm font-semibold text-ink/55">Gift-ready keepsake</p>
        </div>
      </motion.div>
    </div>
  );
}

export default function HeroImmersive() {
  const [videoReady, setVideoReady] = useState(false);
  return (
    <section className="relative overflow-hidden pb-12 pt-14 sm:pb-20 sm:pt-20">
      <div className="container-page grid items-center gap-12 lg:grid-cols-[0.92fr_1.08fr]">
        <div>
          <p className="eyebrow">Snap Magnet USA</p>
          <h1 className="display mt-4">Your favorite memories, made magnetic.</h1>
          <p className="body-large mt-6 max-w-xl">Premium custom photo magnets for gifts, events, weddings, graduations, expos, and business giveaways.</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href="/product/custom-photo-magnet" className="btn-primary">Create Your Magnet</Link>
            <Link href="/quote" className="btn-secondary">Request Event Pricing</Link>
          </div>
          <p className="mt-6 text-sm font-semibold text-ink/55">Custom photo magnets • Gift-ready packs • Event and business orders</p>
        </div>
        <div className="relative min-h-[560px] rounded-[2.5rem] border border-espresso/10 bg-cream/50 p-3 shadow-soft">
          <video
            className={`absolute inset-3 h-[calc(100%-1.5rem)] w-[calc(100%-1.5rem)] rounded-[2rem] object-cover transition-opacity ${videoReady ? "opacity-100" : "opacity-0"}`}
            autoPlay
            muted
            loop
            playsInline
            onCanPlay={() => setVideoReady(true)}
            onError={() => setVideoReady(false)}
          >
            <source src="/media/hero-magnet-loop.webm" type="video/webm" />
            <source src="/media/hero-magnet-loop.mp4" type="video/mp4" />
          </video>
          {!videoReady && <FloatingMagnets />}
        </div>
      </div>
    </section>
  );
}
