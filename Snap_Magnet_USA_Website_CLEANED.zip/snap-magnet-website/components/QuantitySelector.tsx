"use client";

import { formatMoney, getPriceForQuantity, QUANTITIES } from "@/lib/pricing";
import { cn } from "@/lib/utils";

export default function QuantitySelector({ value, onChange }: { value: number; onChange: (value: number) => void }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
      {QUANTITIES.map((qty) => (
        <button
          key={qty}
          type="button"
          onClick={() => onChange(qty)}
          className={cn(
            "rounded-2xl border p-4 text-left transition focus:outline-none focus:ring-4 focus:ring-champagne/15",
            value === qty ? "border-espresso bg-espresso text-cream" : "border-espresso/10 bg-white/65 text-ink hover:border-champagne"
          )}
        >
          <span className="block text-lg font-bold">{qty}</span>
          <span className={cn("block text-xs", value === qty ? "text-cream/70" : "text-ink/50")}>{formatMoney(getPriceForQuantity(qty))}</span>
          {qty === 9 && <span className="mt-2 inline-block rounded-full bg-champagne px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-cream">Popular</span>}
        </button>
      ))}
    </div>
  );
}
