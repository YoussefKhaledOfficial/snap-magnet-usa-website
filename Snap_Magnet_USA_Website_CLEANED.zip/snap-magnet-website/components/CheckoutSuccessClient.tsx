"use client";

import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { trackPurchase } from "@/lib/tracking";

export default function CheckoutSuccessClient() {
  const params = useSearchParams();
  const sessionId = params.get("session_id");
  const demo = params.get("demo");

  useEffect(() => {
    trackPurchase({ sessionId: sessionId || "demo", demo: Boolean(demo) });
  }, [sessionId, demo]);

  if (!demo) return null;

  return <p className="mt-4 rounded-2xl bg-yellow-50 p-4 text-sm font-semibold text-yellow-900">Demo checkout mode is active because Stripe environment variables are not configured yet.</p>;
}
