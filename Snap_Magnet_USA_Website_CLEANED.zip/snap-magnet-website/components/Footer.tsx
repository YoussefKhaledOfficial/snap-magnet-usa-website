"use client";

import Image from "next/image";
import Link from "next/link";
import { trackSocialClick } from "@/lib/tracking";

export default function Footer() {
  return (
    <footer className="border-t border-espresso/10 bg-cream/70">
      <div className="container-page grid gap-10 py-12 lg:grid-cols-[1.3fr_0.7fr_0.7fr_0.9fr]">
        <div>
          <Image src="/brand/logo-primary.png" alt="Snap Magnet USA" width={220} height={110} className="mb-4 h-auto" />
          <p className="max-w-sm text-sm leading-7 text-ink/65">Premium custom photo magnets for gifts, events, and business giveaways. Your favorite memories, made magnetic.</p>
        </div>
        <div>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-[0.18em] text-ink">Shop</h3>
          <div className="grid gap-3 text-sm text-ink/65">
            <Link href="/product/custom-photo-magnet">Create Yours</Link>
            <Link href="/shop">Shop Options</Link>
            <Link href="/events">Events</Link>
            <Link href="/b2b">Business</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-[0.18em] text-ink">Support</h3>
          <div className="grid gap-3 text-sm text-ink/65">
            <Link href="/shipping">Shipping</Link>
            <Link href="/refunds">Refunds</Link>
            <Link href="/privacy">Privacy</Link>
            <Link href="/terms">Terms</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-[0.18em] text-ink">Contact</h3>
          <div className="grid gap-3 text-sm text-ink/65">
            <a href="mailto:snapmagnetusa@gmail.com">snapmagnetusa@gmail.com</a>
            <a href="tel:17738512030">(773) 851-2030</a>
            <a href="https://www.instagram.com/snapmagnet.usa/" target="_blank" rel="noreferrer" onClick={() => trackSocialClick("instagram")}>@snapmagnet.usa</a>
          </div>
        </div>
      </div>
      <div className="container-page border-t border-espresso/10 py-5 text-xs text-ink/50">
        © {new Date().getFullYear()} Snap Magnet USA. Custom-made for your order. Policies are launch drafts and should be reviewed before going live.
      </div>
    </footer>
  );
}
