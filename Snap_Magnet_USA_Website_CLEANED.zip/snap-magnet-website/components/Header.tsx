"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { cn } from "@/lib/utils";

const nav = [
  { href: "/shop", label: "Shop" },
  { href: "/events", label: "Events" },
  { href: "/b2b", label: "Business" },
  { href: "/#how-it-works", label: "How It Works" },
  { href: "/#faq", label: "FAQ" }
];

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-espresso/10 bg-ivory/88 backdrop-blur-xl">
      <div className="container-page flex h-20 items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-3" aria-label="Snap Magnet USA home">
          <Image src="/brand/logo-icon.png" alt="Snap Magnet USA icon" width={44} height={44} className="rounded-xl" priority />
          <Image src="/brand/logo-primary.png" alt="Snap Magnet USA" width={154} height={64} className="hidden h-auto sm:block" priority />
        </Link>
        <nav className="hidden items-center gap-7 text-sm font-semibold text-ink/75 lg:flex" aria-label="Main navigation">
          {nav.map((item) => <Link key={item.href} href={item.href} className="transition hover:text-espresso">{item.label}</Link>)}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          <Link href="/quote" className="btn-secondary px-5 py-2.5">Event Quote</Link>
          <Link href="/product/custom-photo-magnet" className="btn-primary px-5 py-2.5">Create Yours</Link>
        </div>
        <button
          className="rounded-full border border-espresso/15 bg-cream px-4 py-2 text-sm font-bold text-espresso lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
        >
          {open ? "Close" : "Menu"}
        </button>
      </div>
      <div id="mobile-menu" className={cn("container-page overflow-hidden transition-all lg:hidden", open ? "max-h-96 pb-5" : "max-h-0")}> 
        <nav className="grid gap-2 rounded-3xl border border-espresso/10 bg-cream p-3" aria-label="Mobile navigation">
          {nav.map((item) => <Link key={item.href} href={item.href} className="rounded-2xl px-4 py-3 text-sm font-bold text-ink/80 hover:bg-ivory" onClick={() => setOpen(false)}>{item.label}</Link>)}
          <Link href="/quote" className="btn-secondary mt-2" onClick={() => setOpen(false)}>Event Quote</Link>
          <Link href="/product/custom-photo-magnet" className="btn-primary" onClick={() => setOpen(false)}>Create Yours</Link>
        </nav>
      </div>
    </header>
  );
}
