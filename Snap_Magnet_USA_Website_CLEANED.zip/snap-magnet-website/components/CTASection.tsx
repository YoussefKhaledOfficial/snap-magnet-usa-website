import Link from "next/link";

export default function CTASection() {
  return (
    <section className="section pt-0">
      <div className="container-page">
        <div className="rounded-[2.5rem] bg-espresso px-8 py-14 text-center text-cream shadow-soft sm:px-12">
          <p className="eyebrow text-champagne">Create yours</p>
          <h2 className="mx-auto mt-3 max-w-3xl font-heading text-4xl font-semibold leading-tight tracking-[-0.035em] sm:text-6xl">Ready to create your custom magnet?</h2>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-cream/70">Start with one photo, build a gift-ready pack, or request pricing for your next event or business order.</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Link href="/product/custom-photo-magnet" className="inline-flex items-center justify-center rounded-full bg-cream px-6 py-3 text-sm font-bold text-espresso transition hover:-translate-y-0.5">Start Your Order</Link>
            <Link href="/quote" className="inline-flex items-center justify-center rounded-full border border-cream/20 px-6 py-3 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-cream/10">Get a Bulk Quote</Link>
          </div>
        </div>
      </div>
    </section>
  );
}
