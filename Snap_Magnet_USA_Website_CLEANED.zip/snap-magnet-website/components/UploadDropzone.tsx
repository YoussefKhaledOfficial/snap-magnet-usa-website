"use client";

import Image from "next/image";
import { useMemo } from "react";
import { trackUploadStarted } from "@/lib/tracking";

export default function UploadDropzone({ file, onFile }: { file: File | null; onFile: (file: File | null) => void }) {
  const previewUrl = useMemo(() => file ? URL.createObjectURL(file) : "", [file]);

  return (
    <div className="rounded-[2rem] border border-dashed border-espresso/20 bg-white/60 p-4">
      <label className="grid min-h-[260px] cursor-pointer place-items-center overflow-hidden rounded-[1.5rem] bg-ivory/70 text-center transition hover:bg-cream">
        <input
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="sr-only"
          onClick={() => trackUploadStarted()}
          onChange={(event) => onFile(event.target.files?.[0] || null)}
        />
        {previewUrl ? (
          <div className="relative h-full min-h-[260px] w-full">
            <Image src={previewUrl} alt="Uploaded preview" fill className="object-cover" unoptimized />
          </div>
        ) : (
          <div className="p-8">
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-espresso text-2xl text-cream">↑</div>
            <p className="text-lg font-bold text-ink">Upload your photo or logo</p>
            <p className="mt-2 text-sm leading-6 text-ink/55">JPG, PNG, or WebP. Use the highest-resolution version available.</p>
          </div>
        )}
      </label>
      {file && <button type="button" className="mt-3 text-sm font-bold text-espresso underline" onClick={() => onFile(null)}>Remove image</button>}
    </div>
  );
}
