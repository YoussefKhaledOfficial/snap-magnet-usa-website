export default function TestimonialPlaceholder() {
  return (
    <div className="card border-dashed">
      <p className="text-sm font-bold uppercase tracking-[0.18em] text-champagne">Placeholder</p>
      <p className="mt-3 text-sm leading-7 text-ink/60">Add real customer reviews only after you have permission to publish them. Do not use fake testimonials.</p>
    </div>
  );
}
