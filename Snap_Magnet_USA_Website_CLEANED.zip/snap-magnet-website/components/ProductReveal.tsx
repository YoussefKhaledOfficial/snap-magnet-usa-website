"use client";

import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const callouts = ["Vivid photo finish", "Smooth rounded edges", "Strong magnetic backing", "Gift-ready presentation"];

export default function ProductReveal() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const rotate = useTransform(scrollYProgress, [0, 1], [-8, 10]);
  const y = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section ref={ref} className="section overflow-hidden">
      <div className="container-page grid items-center gap-12 lg:grid-cols-2">
        <div>
          <p className="eyebrow">Product reveal</p>
          <h2 className="headline mt-3">A small keepsake with a big first impression.</h2>
          <p className="body-large mt-5">Show the photo surface, edge detail, magnetic backing, and packaging in a cinematic scroll sequence. Replace the placeholder images with final AI renders or product photography when ready.</p>
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {callouts.map((item) => <div className="card p-4 text-sm font-bold text-ink/70" key={item}>{item}</div>)}
          </div>
        </div>
        <div className="relative min-h-[620px]">
          <motion.div style={{ rotate, y }} className="absolute left-1/2 top-8 z-10 w-[82%] max-w-md -translate-x-1/2 rounded-[2.5rem] border border-espresso/10 bg-cream p-4 shadow-soft">
            <div className="relative aspect-square overflow-hidden rounded-[2rem] bg-ivory">
              <Image src="/media/packaging-closed-box-measurements.jpeg" alt="Snap Magnet USA premium packaging box" fill className="object-cover" sizes="(min-width: 1024px) 430px, 86vw" />
            </div>
          </motion.div>
          <motion.div style={{ y: useTransform(scrollYProgress, [0, 1], [80, -10]) }} className="absolute bottom-8 left-4 w-[58%] rounded-[2rem] border border-espresso/10 bg-cream p-3 shadow-card">
            <div className="relative aspect-[4/3] overflow-hidden rounded-[1.5rem] bg-white">
              <Image src="/media/packaging-insert-measurements.jpeg" alt="Snap Magnet USA packaging insert" fill className="object-cover" sizes="300px" />
            </div>
          </motion.div>
          <motion.div style={{ y: useTransform(scrollYProgress, [0, 1], [-20, 50]) }} className="absolute right-0 top-72 w-[46%] rounded-[2rem] border border-espresso/10 bg-espresso p-3 text-cream shadow-card">
            <p className="font-accent text-2xl text-champagne">pick me up!</p>
            <p className="mt-2 text-sm leading-6 text-cream/80">Use this space for a macro magnet surface render, edge thickness, or magnetic backing close-up.</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
