import Link from "next/link";
import type { ProductCardData } from "@/lib/products";

export default function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <Link href={product.href} className="group card flex min-h-[260px] flex-col justify-between transition hover:-translate-y-1 hover:bg-white/80">
      <div>
        <div className="mb-5 inline-flex rounded-full bg-champagne/12 px-3 py-1 text-xs font-bold uppercase tracking-[0.16em] text-champagne">{product.badge}</div>
        <h3 className="font-heading text-3xl font-semibold leading-tight text-ink">{product.title}</h3>
        <p className="mt-4 text-sm leading-7 text-ink/62">{product.description}</p>
      </div>
      <span className="mt-8 text-sm font-bold text-espresso">{product.cta} <span className="transition group-hover:translate-x-1">→</span></span>
    </Link>
  );
}
