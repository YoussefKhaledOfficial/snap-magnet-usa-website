const steps = [
  ["01", "Upload your photo or logo", "Choose a favorite photo, business logo, QR code, or event design."],
  ["02", "Pick your style", "Select the size, shape, finish, and pack size that fits your moment."],
  ["03", "Preview and checkout", "Review your magnet before payment through a simple guest checkout."],
  ["04", "We prepare your order", "Your custom magnets are prepared, packaged, and shipped with care."]
];

export default function HowItWorks() {
  return (
    <section className="section bg-cream/45" id="how-it-works">
      <div className="container-page">
        <div className="max-w-3xl">
          <p className="eyebrow">How it works</p>
          <h2 className="headline mt-3">From upload to gift-ready magnet in a few clean steps.</h2>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {steps.map(([num, title, body]) => (
            <div className="card" key={num}>
              <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-full bg-espresso text-sm font-bold text-cream">{num}</div>
              <h3 className="text-xl font-bold text-ink">{title}</h3>
              <p className="mt-3 text-sm leading-7 text-ink/60">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
