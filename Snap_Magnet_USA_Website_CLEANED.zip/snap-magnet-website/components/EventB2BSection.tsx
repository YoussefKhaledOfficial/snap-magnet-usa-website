import Link from "next/link";

export default function EventB2BSection() {
  return (
    <section className="section" id="events-b2b">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-cream p-8 shadow-soft sm:p-12 lg:p-16">
          <div className="absolute right-0 top-0 h-72 w-72 rounded-full bg-champagne/15 blur-3xl" />
          <div className="relative grid gap-10 lg:grid-cols-[1fr_0.75fr] lg:items-center">
            <div>
              <p className="eyebrow">Events + Business</p>
              <h2 className="headline mt-3">Give guests and customers something they’ll actually keep.</h2>
              <p className="body-large mt-5">Custom magnets are a practical, memorable alternative to disposable giveaways. Use them for event favors, booth giveaways, customer appreciation gifts, QR campaigns, and branded moments that stay visible after the event ends.</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/quote" className="btn-primary">Request Event Pricing</Link>
                <Link href="/b2b" className="btn-secondary">Explore Business Giveaways</Link>
              </div>
            </div>
            <div className="grid gap-4">
              {[
                ["Starter Event Pack", "Best for small gatherings, samples, and family events. Suggested quantity: 50 magnets."],
                ["Signature Event Pack", "Best for weddings, graduations, and private celebrations. Suggested quantity: 100-250 magnets."],
                ["Business Campaign Pack", "Best for expos, QR campaigns, restaurants, real estate, and branded giveaways. Suggested quantity: 250-1,000+ magnets."]
              ].map(([title, copy]) => (
                <div key={title} className="rounded-[1.5rem] border border-espresso/10 bg-white/55 p-5">
                  <h3 className="font-bold text-ink">{title}</h3>
                  <p className="mt-2 text-sm leading-6 text-ink/60">{copy}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
