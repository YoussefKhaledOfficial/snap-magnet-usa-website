const faqs = [
  ["What photo quality should I upload?", "Use the highest-resolution photo available. Bright, clear images with the subject centered usually print best."],
  ["Can I order in bulk?", "Yes. For 50+ magnets, request event or business pricing so we can recommend the right package and timeline."],
  ["Do you offer event packages?", "Yes. Event packages are designed for weddings, graduations, private celebrations, expos, and branded giveaways."],
  ["Can businesses add a logo or QR code?", "Yes. Businesses can use logos, QR codes, campaign artwork, and appointment or promo messaging."],
  ["Do I need an account?", "No. The MVP uses simple guest checkout. Customer accounts and reorder tools can be added later."],
  ["How long does production take?", "Most custom orders are expected to be prepared within 2–4 business days after details and payment are received. Large orders may take longer."],
  ["Can I approve the design before printing?", "The product builder includes a preview. For large or design-assisted orders, approval can be handled through the quote workflow."],
];

export default function FAQ() {
  return (
    <section className="section" id="faq">
      <div className="container-page">
        <div className="max-w-3xl">
          <p className="eyebrow">FAQ</p>
          <h2 className="headline mt-3">Simple answers before you order.</h2>
        </div>
        <div className="mt-10 grid gap-4 lg:grid-cols-2">
          {faqs.map(([q, a]) => (
            <details key={q} className="card group">
              <summary className="cursor-pointer list-none text-lg font-bold text-ink">{q}<span className="float-right text-champagne group-open:rotate-45">+</span></summary>
              <p className="mt-4 text-sm leading-7 text-ink/60">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
