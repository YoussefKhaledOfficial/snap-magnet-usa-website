"use client";

import { formatMoney, getPriceForQuantity, getUnitPrice } from "@/lib/pricing";

export default function PriceSummary({ quantity }: { quantity: number }) {
  return (
    <aside className="rounded-[2rem] border border-espresso/10 bg-cream p-6 shadow-card">
      <p className="text-sm font-bold uppercase tracking-[0.18em] text-champagne">Price summary</p>
      <div className="mt-5 flex items-end justify-between gap-4">
        <div>
          <p className="text-sm text-ink/55">{quantity} custom magnet{quantity === 1 ? "" : "s"}</p>
          <p className="mt-1 font-heading text-5xl font-semibold text-ink">{formatMoney(getPriceForQuantity(quantity))}</p>
        </div>
        <p className="mb-2 rounded-full bg-white px-3 py-1 text-xs font-bold text-ink/60">{formatMoney(getUnitPrice(quantity))}/ea</p>
      </div>
      <p className="mt-5 text-xs leading-6 text-ink/50">Shipping, taxes, and optional add-ons are handled at checkout or during quote review. Prices are editable in <code>/lib/pricing.ts</code>.</p>
    </aside>
  );
}
