const items = ["Upload your photo", "Preview before checkout", "Bulk and event options", "Made custom for your order"];

export default function TrustBar() {
  return (
    <section className="container-page">
      <div className="grid gap-3 rounded-[2rem] border border-espresso/10 bg-cream/80 p-3 shadow-card sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <div key={item} className="rounded-3xl bg-white/55 px-5 py-4 text-sm font-bold text-ink/70">
            <span className="mr-2 text-champagne">✦</span>{item}
          </div>
        ))}
      </div>
    </section>
  );
}
