"use client";

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import UploadDropzone from "@/components/UploadDropzone";
import QuantitySelector from "@/components/QuantitySelector";
import PriceSummary from "@/components/PriceSummary";
import { ProductBuilderInput, productBuilderSchema } from "@/lib/validators";
import { getPriceForQuantity } from "@/lib/pricing";
import { getSupabaseBrowserClient } from "@/lib/supabase";
import { trackAddToCart, trackBeginCheckout, trackCustomizationComplete, trackUploadCompleted } from "@/lib/tracking";

export default function ProductBuilder() {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const form = useForm<ProductBuilderInput>({
    resolver: zodResolver(productBuilderSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      quantity: 4,
      shape: "square",
      size: "3x3 in",
      finish: "glossy",
      notes: ""
    }
  });

  const quantity = form.watch("quantity");
  const shape = form.watch("shape");
  const size = form.watch("size");
  const finish = form.watch("finish");
  const watchedName = form.watch("customerName");
  const watchedEmail = form.watch("customerEmail");
  const isConfigured = Boolean(quantity && shape && size && finish && file && watchedName && watchedEmail);

  useEffect(() => {
    if (isConfigured) trackCustomizationComplete();
  }, [isConfigured]);

  const previewLabel = useMemo(() => `${quantity}-pack • ${shape} • ${size} • ${finish}`, [quantity, shape, size, finish]);

  async function uploadCustomerFile(): Promise<string> {
    if (!file) throw new Error("Please upload a photo before checkout.");
    const response = await fetch("/api/create-upload-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileName: file.name, contentType: file.type })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create upload URL.");
    if (data.demo) {
      trackUploadCompleted();
      return data.path || `demo/${file.name}`;
    }
    const supabase = getSupabaseBrowserClient();
    if (!supabase) throw new Error("Supabase public environment variables are missing.");
    const bucket = process.env.NEXT_PUBLIC_SUPABASE_BUCKET_NAME || "order-uploads";
    const { error: uploadError } = await supabase.storage.from(bucket).uploadToSignedUrl(data.path, data.token, file);
    if (uploadError) throw uploadError;
    trackUploadCompleted();
    return data.path;
  }

  async function onSubmit(values: ProductBuilderInput) {
    setError(null);
    setLoading(true);
    try {
      const uploadPath = await uploadCustomerFile();
      trackAddToCart({ productId: "custom-photo-magnet", quantity: values.quantity, value: getPriceForQuantity(values.quantity) / 100 });
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, productId: "custom-photo-magnet", uploadPath })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start checkout.");
      trackBeginCheckout({ productId: "custom-photo-magnet", quantity: values.quantity, value: getPriceForQuantity(values.quantity) / 100 });
      window.location.href = data.url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-8 lg:grid-cols-[1fr_0.78fr]">
      <div className="grid gap-6">
        <div className="card">
          <label className="label">Your photo or logo</label>
          <UploadDropzone file={file} onFile={setFile} />
          <p className="mt-3 text-xs leading-6 text-ink/50">Your uploaded photo is used only to prepare your order.</p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="customerName">Name</label>
            <input id="customerName" className="input" placeholder="Your name" {...form.register("customerName")} />
            {form.formState.errors.customerName && <p className="mt-2 text-xs font-bold text-red-700">{form.formState.errors.customerName.message}</p>}
          </div>
          <div>
            <label className="label" htmlFor="customerEmail">Email</label>
            <input id="customerEmail" className="input" placeholder="you@example.com" {...form.register("customerEmail")} />
            {form.formState.errors.customerEmail && <p className="mt-2 text-xs font-bold text-red-700">{form.formState.errors.customerEmail.message}</p>}
          </div>
        </div>
        <div className="card">
          <label className="label">Quantity</label>
          <QuantitySelector value={quantity} onChange={(v) => form.setValue("quantity", v, { shouldValidate: true })} />
        </div>
        <div className="grid gap-5 sm:grid-cols-3">
          <div>
            <label className="label" htmlFor="shape">Shape</label>
            <select id="shape" className="input" {...form.register("shape")}> 
              <option value="square">Square</option>
              <option value="rectangle">Rectangle</option>
              <option value="round">Round</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="size">Size</label>
            <select id="size" className="input" {...form.register("size")}> 
              <option value="3x3 in">3x3 in</option>
              <option value="2.5x3.5 in">2.5x3.5 in</option>
              <option value="3x4 in">3x4 in</option>
              <option value="2.25 in round">2.25 in round</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="finish">Finish</label>
            <select id="finish" className="input" {...form.register("finish")}> 
              <option value="glossy">Glossy photo finish</option>
              <option value="matte">Matte premium finish</option>
            </select>
          </div>
        </div>
        <div>
          <label className="label" htmlFor="notes">Optional notes</label>
          <textarea id="notes" className="input min-h-32" placeholder="Tell us about cropping, names, dates, or event details." {...form.register("notes")} />
        </div>
      </div>
      <div className="lg:sticky lg:top-28 lg:self-start">
        <div className="card mb-5">
          <p className="text-sm font-bold uppercase tracking-[0.18em] text-champagne">Live preview</p>
          <div className="mt-5 rounded-[2rem] border border-espresso/10 bg-white p-4 shadow-card">
            <div className="relative grid aspect-square place-items-center overflow-hidden rounded-[1.5rem] bg-ivory text-center">
              {file ? <img src={URL.createObjectURL(file)} alt="Customer upload preview" className="h-full w-full object-cover" /> : <span className="px-8 font-heading text-4xl font-semibold text-espresso/55">Your photo here</span>}
            </div>
          </div>
          <p className="mt-4 text-sm font-semibold text-ink/65">{previewLabel}</p>
          <p className="mt-2 text-xs leading-6 text-ink/50">Most custom orders are expected to be prepared within 2–4 business days after order details and payment are received.</p>
        </div>
        <PriceSummary quantity={quantity} />
        {error && <p className="mt-4 rounded-2xl bg-red-50 p-4 text-sm font-semibold text-red-800">{error}</p>}
        <button type="submit" className="btn-primary mt-5 w-full py-4" disabled={loading}>
          {loading ? "Preparing checkout..." : "Add to Checkout"}
        </button>
        <p className="mt-4 text-center text-xs text-ink/45">Secure checkout powered by Stripe. Guest checkout — no account required.</p>
      </div>
    </form>
  );
}
