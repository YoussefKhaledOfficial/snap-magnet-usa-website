import Image from "next/image";

const features = [
  ["Photo-forward finish", "Designed to make meaningful pictures feel display-worthy, giftable, and personal."],
  ["Premium presentation", "Your visual identity already supports a more elevated packaging experience than a standard print-shop order."],
  ["Event-ready", "Perfect for personal celebrations, corporate gifting, QR campaigns, and high-volume keepsakes."],
  ["Built for ads", "The site includes tracking hooks for purchases, quote leads, uploads, and media-buying funnels."]
];

export default function QualityShowcase() {
  return (
    <section className="section" id="quality">
      <div className="container-page">
        <div className="grid items-end gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow">Premium feel</p>
            <h2 className="headline mt-3">Small keepsakes. Big first impression.</h2>
            <p className="body-large mt-5">Every magnet should feel worth keeping. From the photo finish to the packaging experience, Snap Magnet USA is built to feel personal, giftable, and elevated.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative aspect-square overflow-hidden rounded-[2rem] border border-espresso/10 bg-cream shadow-card">
              <Image src="/media/packaging-closed-box-measurements.jpeg" alt="Closed Snap Magnet USA packaging" fill className="object-cover" sizes="320px" />
            </div>
            <div className="relative aspect-square overflow-hidden rounded-[2rem] border border-espresso/10 bg-cream shadow-card">
              <Image src="/media/packaging-flat-dieline.jpeg" alt="Flat Snap Magnet USA packaging design" fill className="object-cover" sizes="320px" />
            </div>
          </div>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {features.map(([title, body]) => (
            <div key={title} className="card">
              <h3 className="text-lg font-bold text-ink">{title}</h3>
              <p className="mt-3 text-sm leading-7 text-ink/60">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
