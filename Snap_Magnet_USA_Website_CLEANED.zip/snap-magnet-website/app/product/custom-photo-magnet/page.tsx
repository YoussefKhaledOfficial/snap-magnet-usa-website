import type { Metadata } from "next";
import ProductBuilder from "@/components/ProductBuilder";
import FAQ from "@/components/FAQ";
import { formatMoney, getPriceForQuantity } from "@/lib/pricing";

export const metadata: Metadata = {
  title: "Custom Photo Magnet",
  description: "Upload your photo and create a premium custom photo magnet with guest checkout and event-ready pack options."
};

export default function CustomPhotoMagnetPage() {
  return (
    <>
      <section className="section pb-8">
        <div className="container-page grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
          <div>
            <p className="eyebrow">Custom Photo Magnet</p>
            <h1 className="display mt-4">Create a magnet worth keeping.</h1>
          </div>
          <div>
            <p className="body-large">Upload your photo or logo, choose your size and finish, preview the result, and checkout securely. Recommended default: square 3x3 in, glossy finish, 4-pack.</p>
            <div className="mt-5 flex flex-wrap gap-3 text-sm font-bold text-ink/65">
              <span className="rounded-full bg-cream px-4 py-2">Starts at {formatMoney(getPriceForQuantity(1))}</span>
              <span className="rounded-full bg-cream px-4 py-2">Guest checkout</span>
              <span className="rounded-full bg-cream px-4 py-2">Custom-made for your order</span>
            </div>
          </div>
        </div>
      </section>
      <section className="section pt-8">
        <div className="container-page">
          <ProductBuilder />
        </div>
      </section>
      <FAQ />
    </>
  );
}
