import HeroImmersive from "@/components/HeroImmersive";
import TrustBar from "@/components/TrustBar";
import ProductReveal from "@/components/ProductReveal";
import HowItWorks from "@/components/HowItWorks";
import ProductCard from "@/components/ProductCard";
import QualityShowcase from "@/components/QualityShowcase";
import OccasionGrid from "@/components/OccasionGrid";
import EventB2BSection from "@/components/EventB2BSection";
import FAQ from "@/components/FAQ";
import CTASection from "@/components/CTASection";
import { shopPreviewProducts } from "@/lib/products";

export default function HomePage() {
  return (
    <>
      <HeroImmersive />
      <TrustBar />
      <ProductReveal />
      <HowItWorks />
      <section className="section" id="shop-preview">
        <div className="container-page">
          <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="eyebrow">Shop + Quote</p>
              <h2 className="headline mt-3">Start with one photo or build a full event moment.</h2>
            </div>
            <a href="/shop" className="btn-secondary">View all options</a>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {shopPreviewProducts.map((product) => <ProductCard key={product.title} product={product} />)}
          </div>
        </div>
      </section>
      <QualityShowcase />
      <OccasionGrid />
      <EventB2BSection />
      <FAQ />
      <CTASection />
    </>
  );
}
