import type { Metadata } from "next";
import QuoteForm from "@/components/QuoteForm";

export const metadata: Metadata = {
  title: "Request Event or Business Pricing",
  description: "Request pricing for event packages, business giveaways, QR campaigns, and bulk custom photo magnets."
};

export default function QuotePage() {
  return (
    <section className="section">
      <div className="container-page grid gap-10 lg:grid-cols-[0.78fr_1fr] lg:items-start">
        <div className="lg:sticky lg:top-28">
          <p className="eyebrow">Quote request</p>
          <h1 className="display mt-4">Tell us about your event or campaign.</h1>
          <p className="body-large mt-6">Share the date, quantity, location, and design needs. We’ll use this to recommend a package and pricing.</p>
          <div className="mt-8 rounded-[2rem] border border-espresso/10 bg-cream p-6 text-sm leading-7 text-ink/65">
            <p className="font-bold text-ink">Contact</p>
            <p>Email: snapmagnetusa@gmail.com</p>
            <p>Phone: (773) 851-2030</p>
            <p>Instagram: @snapmagnet.usa</p>
          </div>
        </div>
        <QuoteForm />
      </div>
    </section>
  );
}
