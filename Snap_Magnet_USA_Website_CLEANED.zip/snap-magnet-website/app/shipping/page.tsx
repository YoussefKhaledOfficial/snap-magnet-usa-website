function PolicyLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="section">
      <div className="container-page max-w-4xl">
        <p className="eyebrow">Policy</p>
        <h1 className="display mt-4">{title}</h1>
        <div className="prose prose-stone mt-10 max-w-none rounded-[2rem] border border-espresso/10 bg-cream p-6 text-ink/75 shadow-card prose-headings:font-heading prose-headings:text-ink prose-p:leading-8 prose-li:leading-8">
          {children}
        </div>
      </div>
    </section>
  );
}

export default function ShippingPage() {
  return (
    <PolicyLayout title="Shipping Policy">
      <p><strong>Last updated:</strong> [Add launch date]</p>
      <p>Snap Magnet USA currently plans to ship within the United States.</p>
      <h2>Processing time</h2>
      <p>Most custom orders are expected to be prepared within 2–4 business days after order details, photos, and payment are received. Larger event or business orders may require more time.</p>
      <h2>Shipping time</h2>
      <p>Shipping time depends on the selected carrier and service level. Standard shipping commonly takes several business days after production is complete.</p>
      <h2>Event deadlines</h2>
      <p>If ordering for an event date, place the order early and include the event date in your notes or quote request.</p>
    </PolicyLayout>
  );
}
