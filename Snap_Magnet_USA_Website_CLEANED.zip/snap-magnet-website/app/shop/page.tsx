import type { Metadata } from "next";
import ProductCard from "@/components/ProductCard";
import CTASection from "@/components/CTASection";
import { shopProducts } from "@/lib/products";

export const metadata: Metadata = {
  title: "Shop Custom Photo Magnets",
  description: "Shop premium custom photo magnets, gift-ready photo magnet packs, event packages, and business giveaway magnets."
};

const filters = ["Personal gifts", "Events", "Business", "Bulk"];

export default function ShopPage() {
  return (
    <>
      <section className="section pb-8">
        <div className="container-page">
          <p className="eyebrow">Shop</p>
          <h1 className="display mt-4 max-w-4xl">Choose the magnet experience that fits your moment.</h1>
          <p className="body-large mt-6 max-w-2xl">Start with a simple custom photo magnet, build a gift-ready pack, or request pricing for event and business quantities.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            {filters.map((f) => <span key={f} className="rounded-full border border-espresso/10 bg-cream px-4 py-2 text-sm font-bold text-ink/65">{f}</span>)}
          </div>
        </div>
      </section>
      <section className="section pt-8">
        <div className="container-page grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {shopProducts.map((product) => <ProductCard key={product.title} product={product} />)}
        </div>
      </section>
      <CTASection />
    </>
  );
}
