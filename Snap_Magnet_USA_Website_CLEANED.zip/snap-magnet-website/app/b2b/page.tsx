import type { Metadata } from "next";
import Link from "next/link";
import { EVENT_QUOTE_ANCHORS } from "@/lib/pricing";

export const metadata: Metadata = {
  title: "Business Giveaway Magnets",
  description: "Premium custom magnets for expos, QR campaigns, real estate, restaurants, schools, nonprofits, customer appreciation, and brand activations."
};

const useCases = ["Expo booth giveaways", "QR code campaigns", "Customer appreciation gifts", "Restaurant promotions", "Real estate open houses", "School and nonprofit campaigns", "Appointment reminders", "Local business branding"];

export default function B2BPage() {
  return (
    <>
      <section className="section pb-10">
        <div className="container-page grid gap-10 lg:grid-cols-[1fr_0.8fr] lg:items-center">
          <div>
            <p className="eyebrow">Business</p>
            <h1 className="display mt-4">Branded magnets people keep seeing.</h1>
            <p className="body-large mt-6 max-w-2xl">Premium custom magnets for expos, corporate giveaways, QR campaigns, real estate, restaurants, schools, nonprofits, and local business promotions.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/quote" className="btn-primary">Get a Business Quote</Link>
              <Link href="/product/custom-photo-magnet" className="btn-secondary">Order a sample pack</Link>
            </div>
          </div>
          <div className="card bg-espresso text-cream">
            <p className="font-heading text-4xl font-semibold">Most giveaways are forgotten.</p>
            <p className="mt-4 leading-8 text-cream/72">A well-designed magnet stays on fridges, lockers, office boards, and workspaces — keeping your brand, QR code, promotion, or event message visible after the first interaction.</p>
          </div>
        </div>
      </section>
      <section className="section bg-cream/45">
        <div className="container-page">
          <h2 className="headline">Business use cases</h2>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {useCases.map((item) => <div key={item} className="rounded-[1.5rem] border border-espresso/10 bg-white/60 p-5 text-sm font-bold text-ink/70">✦ {item}</div>)}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container-page">
          <div className="mb-8 max-w-3xl">
            <p className="eyebrow">Quote anchors</p>
            <h2 className="headline mt-3">Premium volume pricing to start the conversation.</h2>
            <p className="body-large mt-4">These are starting anchors only. Final pricing depends on design complexity, packaging, timeline, and quantity.</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            {EVENT_QUOTE_ANCHORS.map((item) => (
              <div key={item.quantity} className="card">
                <p className="text-sm font-bold text-ink/55">{item.quantity}</p>
                <p className="mt-3 font-heading text-4xl font-semibold text-ink">{item.price}</p>
                <p className="mt-2 text-xs font-bold uppercase tracking-wider text-champagne">{item.unit}</p>
              </div>
            ))}
          </div>
          <Link href="/quote" className="btn-primary mt-10">Request a Custom Quote</Link>
        </div>
      </section>
    </>
  );
}
