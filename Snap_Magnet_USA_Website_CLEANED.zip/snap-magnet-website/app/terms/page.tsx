function PolicyLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="section">
      <div className="container-page max-w-4xl">
        <p className="eyebrow">Policy</p>
        <h1 className="display mt-4">{title}</h1>
        <div className="prose prose-stone mt-10 max-w-none rounded-[2rem] border border-espresso/10 bg-cream p-6 text-ink/75 shadow-card prose-headings:font-heading prose-headings:text-ink prose-p:leading-8 prose-li:leading-8">
          {children}
        </div>
      </div>
    </section>
  );
}

export default function TermsPage() {
  return (
    <PolicyLayout title="Terms of Service">
      <p><strong>Last updated:</strong> [Add launch date]</p>
      <p>These terms are a launch draft. Review with a qualified professional before accepting orders.</p>
      <h2>Custom products</h2>
      <p>Snap Magnet USA products are custom-made based on customer-provided photos, logos, artwork, names, dates, and order details.</p>
      <h2>Customer content</h2>
      <p>By uploading content, you confirm that you have the right to use it for your custom order and that it does not violate the rights of others.</p>
      <h2>Order accuracy</h2>
      <p>Customers are responsible for reviewing uploaded images, spelling, dates, shipping addresses, and order details before checkout.</p>
      <h2>Contact</h2>
      <p>Email snapmagnetusa@gmail.com for support.</p>
    </PolicyLayout>
  );
}
