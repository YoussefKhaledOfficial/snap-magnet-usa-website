function PolicyLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="section">
      <div className="container-page max-w-4xl">
        <p className="eyebrow">Policy</p>
        <h1 className="display mt-4">{title}</h1>
        <div className="prose prose-stone mt-10 max-w-none rounded-[2rem] border border-espresso/10 bg-cream p-6 text-ink/75 shadow-card prose-headings:font-heading prose-headings:text-ink prose-p:leading-8 prose-li:leading-8">
          {children}
        </div>
      </div>
    </section>
  );
}

export default function RefundsPage() {
  return (
    <PolicyLayout title="Refund Policy">
      <p><strong>Last updated:</strong> [Add launch date]</p>
      <p>Snap Magnet USA products are personalized and custom-made for each order. Because of this, orders may not be refundable once production begins unless there is an approved issue with the product or fulfillment.</p>
      <h2>Eligible issues for review</h2>
      <ul><li>Product arrives damaged</li><li>Wrong item or quantity sent</li><li>Clear production defect</li><li>Major mismatch caused by production error</li><li>Order lost in transit, subject to carrier review</li></ul>
      <h2>Reporting window</h2>
      <p>Contact snapmagnetusa@gmail.com within 5 days of delivery with the order number, issue description, and clear photos when applicable.</p>
    </PolicyLayout>
  );
}
