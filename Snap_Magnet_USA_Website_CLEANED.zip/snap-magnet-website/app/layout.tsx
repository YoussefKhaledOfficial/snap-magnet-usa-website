import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TrackingPixels from "@/components/TrackingPixels";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: {
    default: "Snap Magnet USA | Custom Photo Magnets for Gifts, Events & Business",
    template: "%s | Snap Magnet USA"
  },
  description: "Create premium custom photo magnets for gifts, events, weddings, graduations, expos, and branded giveaways.",
  openGraph: {
    title: "Snap Magnet USA",
    description: "Premium custom photo magnets for gifts, events, and business giveaways.",
    url: "/",
    siteName: "Snap Magnet USA",
    images: [{ url: "/brand/logo-primary.png", width: 1200, height: 1200 }],
    locale: "en_US",
    type: "website"
  },
  icons: {
    icon: "/brand/favicon-512.png",
    apple: "/brand/favicon-512.png"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <TrackingPixels />
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
