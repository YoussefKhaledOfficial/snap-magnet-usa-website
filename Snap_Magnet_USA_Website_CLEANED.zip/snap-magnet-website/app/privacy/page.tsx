function PolicyLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="section">
      <div className="container-page max-w-4xl">
        <p className="eyebrow">Policy</p>
        <h1 className="display mt-4">{title}</h1>
        <div className="prose prose-stone mt-10 max-w-none rounded-[2rem] border border-espresso/10 bg-cream p-6 text-ink/75 shadow-card prose-headings:font-heading prose-headings:text-ink prose-p:leading-8 prose-li:leading-8">
          {children}
        </div>
      </div>
    </section>
  );
}

export default function PrivacyPage() {
  return (
    <PolicyLayout title="Privacy Policy">
      <p><strong>Last updated:</strong> [Add launch date]</p>
      <p>This draft privacy policy explains how Snap Magnet USA may collect and use information provided through this website. Review this with a qualified professional before launch.</p>
      <h2>Information we collect</h2>
      <p>We may collect your name, email, phone number, shipping details, order details, uploaded photos or artwork, quote request information, and analytics data.</p>
      <h2>How information is used</h2>
      <p>Information is used to prepare custom orders, respond to quote requests, provide customer support, process payments, improve the website, and measure marketing performance.</p>
      <h2>Uploaded photos</h2>
      <p>Uploaded photos are used only to prepare your order and should be stored privately. Do not upload content you do not have rights to use.</p>
      <h2>Contact</h2>
      <p>Email snapmagnetusa@gmail.com with privacy questions.</p>
    </PolicyLayout>
  );
}
