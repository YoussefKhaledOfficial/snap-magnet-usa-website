import type { Metadata } from "next";
import Link from "next/link";
import FAQ from "@/components/FAQ";

export const metadata: Metadata = {
  title: "Event Magnet Packages",
  description: "Premium custom magnets for weddings, engagements, graduations, baby showers, birthdays, school events, and private celebrations."
};

const useCases = ["Wedding favors", "Engagement party favors", "Save-the-date magnets", "Graduation keepsakes", "Birthday party gifts", "Baby shower favors", "School and team events", "Family reunions"];
const packages = [
  ["Starter Event Pack", "Best for small gatherings, family events, and samples.", "Suggested quantity: 50 magnets"],
  ["Signature Event Pack", "Best for weddings, graduations, and private celebrations.", "Suggested quantity: 100–250 magnets"],
  ["Keepsake Celebration Pack", "Best for larger parties, schools, and multi-photo layouts.", "Suggested quantity: 250+ magnets"]
];

export default function EventsPage() {
  return (
    <>
      <section className="section pb-10">
        <div className="container-page grid gap-10 lg:grid-cols-[1fr_0.75fr] lg:items-center">
          <div>
            <p className="eyebrow">Events</p>
            <h1 className="display mt-4">Custom magnets for moments guests will remember.</h1>
            <p className="body-large mt-6 max-w-2xl">Create premium photo magnets for weddings, engagements, graduations, baby showers, birthdays, school events, and private celebrations.</p>
            <Link href="/quote" className="btn-primary mt-8">Request Event Pricing</Link>
          </div>
          <div className="card">
            <p className="font-accent text-3xl text-champagne">event-ready</p>
            <p className="mt-3 text-lg leading-8 text-ink/70">A great event favor should feel personal, useful, and worth keeping. Snap Magnet USA helps turn your photos, dates, names, and event artwork into gift-ready magnets guests can display long after the event.</p>
          </div>
        </div>
      </section>
      <section className="section bg-cream/45">
        <div className="container-page">
          <h2 className="headline">Popular event uses</h2>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {useCases.map((item) => <div key={item} className="rounded-[1.5rem] border border-espresso/10 bg-white/60 p-5 text-sm font-bold text-ink/70">✦ {item}</div>)}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container-page">
          <h2 className="headline">Package examples</h2>
          <div className="mt-8 grid gap-5 lg:grid-cols-3">
            {packages.map(([title, body, qty]) => (
              <div key={title} className="card">
                <h3 className="font-heading text-3xl font-semibold text-ink">{title}</h3>
                <p className="mt-4 text-sm leading-7 text-ink/60">{body}</p>
                <p className="mt-5 rounded-full bg-white px-4 py-2 text-sm font-bold text-ink/65">{qty}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 rounded-[2rem] bg-espresso p-8 text-cream sm:p-10">
            <h3 className="font-heading text-4xl font-semibold">Planning around a date?</h3>
            <p className="mt-3 max-w-2xl leading-8 text-cream/70">Include the event date in your request so we can recommend a production timeline and package size.</p>
            <Link href="/quote" className="mt-6 inline-flex rounded-full bg-cream px-6 py-3 text-sm font-bold text-espresso">Request Event Pricing</Link>
          </div>
        </div>
      </section>
      <FAQ />
    </>
  );
}
