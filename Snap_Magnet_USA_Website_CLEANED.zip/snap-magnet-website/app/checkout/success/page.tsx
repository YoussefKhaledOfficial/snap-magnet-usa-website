import Link from "next/link";
import { Suspense } from "react";
import CheckoutSuccessClient from "@/components/CheckoutSuccessClient";

export default function CheckoutSuccessPage() {
  return (
    <section className="section">
      <div className="container-page max-w-3xl text-center">
        <p className="eyebrow">Order received</p>
        <h1 className="display mt-4">Thank you.</h1>
        <p className="body-large mt-6">Your Snap Magnet USA order was received. A confirmation email will be sent after payment confirmation and order processing are connected.</p>
        <Suspense fallback={null}>
          <CheckoutSuccessClient />
        </Suspense>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Link href="/shop" className="btn-primary">Back to shop</Link>
          <Link href="/quote" className="btn-secondary">Request event pricing</Link>
        </div>
      </div>
    </section>
  );
}
