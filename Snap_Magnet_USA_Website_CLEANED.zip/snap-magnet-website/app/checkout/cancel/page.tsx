import Link from "next/link";

export default function CheckoutCancelPage() {
  return (
    <section className="section">
      <div className="container-page max-w-3xl text-center">
        <p className="eyebrow">Checkout canceled</p>
        <h1 className="display mt-4">No worries.</h1>
        <p className="body-large mt-6">Your checkout was canceled and no payment was completed. You can return to your custom magnet order anytime.</p>
        <Link href="/product/custom-photo-magnet" className="btn-primary mt-8">Return to Product Builder</Link>
      </div>
    </section>
  );
}
