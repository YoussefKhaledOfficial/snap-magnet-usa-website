import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getSupabaseAdmin, SUPABASE_BUCKET } from "@/lib/supabase";
import { uploadRequestSchema } from "@/lib/validators";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const parsed = uploadRequestSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid upload." }, { status: 400 });
  }

  const ext = parsed.data.fileName.split(".").pop()?.toLowerCase() || "jpg";
  const path = `orders/${new Date().toISOString().slice(0, 10)}/${randomUUID()}.${ext}`;
  const supabase = getSupabaseAdmin();

  if (!supabase) {
    if (process.env.NODE_ENV !== "production") {
      return NextResponse.json({ demo: true, path });
    }
    return NextResponse.json({ error: "Upload service is not configured." }, { status: 500 });
  }

  const { data, error } = await supabase.storage.from(SUPABASE_BUCKET).createSignedUploadUrl(path);
  if (error || !data) {
    return NextResponse.json({ error: error?.message || "Could not create upload URL." }, { status: 500 });
  }

  return NextResponse.json({ path, token: data.token, signedUrl: data.signedUrl });
}
