import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { getStripe } from "@/lib/stripe";
import { getSupabaseAdmin } from "@/lib/supabase";
import { sendOrderConfirmation } from "@/lib/email";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const stripe = getStripe();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const signature = req.headers.get("stripe-signature");

  if (!stripe || !webhookSecret || !signature) {
    return NextResponse.json({ error: "Stripe webhook is not configured." }, { status: 500 });
  }

  const body = await req.text();
  let event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Invalid webhook signature." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const metadata = session.metadata || {};
    const supabase = getSupabaseAdmin();
    if (supabase) {
      await supabase.from("orders").upsert({
        stripe_session_id: session.id,
        customer_name: metadata.customerName || "",
        customer_email: metadata.customerEmail || session.customer_email || "",
        product_id: metadata.productId || "custom-photo-magnet",
        quantity: Number(metadata.quantity || 0),
        shape: metadata.shape || "",
        size: metadata.size || "",
        finish: metadata.finish || "",
        upload_path: metadata.uploadPath || "",
        notes: metadata.notes || "",
        amount_total: session.amount_total || 0,
        currency: session.currency || "usd",
        status: "paid",
        fulfillment_status: "new"
      }, { onConflict: "stripe_session_id" });
    }

    if (metadata.customerEmail) {
      await sendOrderConfirmation({
        customerEmail: metadata.customerEmail,
        customerName: metadata.customerName || "there",
        quantity: Number(metadata.quantity || 0),
        shape: metadata.shape || "",
        size: metadata.size || "",
        finish: metadata.finish || ""
      });
    }
  }

  return NextResponse.json({ received: true });
}
