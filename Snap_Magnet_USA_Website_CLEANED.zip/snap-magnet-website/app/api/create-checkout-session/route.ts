import { NextResponse } from "next/server";
import { getStripe } from "@/lib/stripe";
import { getPriceForQuantity } from "@/lib/pricing";
import { checkoutRequestSchema } from "@/lib/validators";
import { getSiteUrl } from "@/lib/utils";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const parsed = checkoutRequestSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid checkout data." }, { status: 400 });
  }

  const data = parsed.data;
  const siteUrl = getSiteUrl(req.url);
  const stripe = getStripe();
  const amount = getPriceForQuantity(data.quantity);

  if (!stripe) {
    if (process.env.NODE_ENV !== "production") {
      return NextResponse.json({ url: `${siteUrl}/checkout/success?demo=1` });
    }
    return NextResponse.json({ error: "Stripe is not configured." }, { status: 500 });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: data.customerEmail,
    line_items: [
      {
        price_data: {
          currency: "usd",
          unit_amount: amount,
          product_data: {
            name: `${data.quantity}-Pack Custom Photo Magnets`,
            description: `${data.shape} • ${data.size} • ${data.finish} finish`
          }
        },
        quantity: 1
      }
    ],
    allow_promotion_codes: true,
    shipping_address_collection: { allowed_countries: ["US"] },
    metadata: {
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      productId: data.productId,
      quantity: String(data.quantity),
      shape: data.shape,
      size: data.size,
      finish: data.finish,
      uploadPath: data.uploadPath,
      notes: data.notes || ""
    },
    success_url: `${siteUrl}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${siteUrl}/checkout/cancel`
  });

  return NextResponse.json({ url: session.url });
}
