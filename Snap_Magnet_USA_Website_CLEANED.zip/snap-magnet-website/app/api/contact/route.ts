import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  console.log("Contact form placeholder", body);
  return NextResponse.json({ ok: true, message: "Contact endpoint placeholder. Use quote form or connect email service." });
}
