import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase";
import { sendQuoteNotification } from "@/lib/email";
import { quoteRequestSchema } from "@/lib/validators";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const parsed = quoteRequestSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid quote request." }, { status: 400 });
  }

  const data = parsed.data;
  const supabase = getSupabaseAdmin();

  if (supabase) {
    await supabase.from("quote_requests").insert({
      full_name: data.fullName,
      email: data.email,
      phone: data.phone,
      company: data.company,
      event_type: data.eventType,
      event_date: data.eventDate || null,
      city_state: data.cityState,
      quantity_range: data.quantityRange,
      needs_design_help: data.needsDesignHelp,
      message: data.message,
      utm_source: data.utmSource,
      utm_medium: data.utmMedium,
      utm_campaign: data.utmCampaign,
      utm_content: data.utmContent,
      utm_term: data.utmTerm
    });
  }

  await sendQuoteNotification({
    fullName: data.fullName,
    email: data.email,
    phone: data.phone,
    company: data.company,
    eventType: data.eventType,
    quantityRange: data.quantityRange,
    cityState: data.cityState,
    message: data.message
  });

  return NextResponse.json({ ok: true });
}
