# Snap Magnet USA Website

Premium ecommerce + event/B2B lead-generation website for Snap Magnet USA.

Built for deployment on Netlify using:

- Next.js App Router
- TypeScript
- Tailwind CSS
- Framer Motion
- React Hook Form + Zod
- Stripe Checkout
- Supabase Storage + Database
- Resend-ready email notifications
- GA4 / GTM / Meta / TikTok / Clarity / PostHog tracking hooks

The site intentionally avoids mentioning Egypt or implying “Made in USA.” Use only verified manufacturing/origin claims.

## Project structure

```txt
app/
  page.tsx
  layout.tsx
  globals.css
  shop/page.tsx
  product/custom-photo-magnet/page.tsx
  events/page.tsx
  b2b/page.tsx
  quote/page.tsx
  checkout/success/page.tsx
  checkout/cancel/page.tsx
  privacy/page.tsx
  terms/page.tsx
  shipping/page.tsx
  refunds/page.tsx
  api/create-checkout-session/route.ts
  api/stripe-webhook/route.ts
  api/create-upload-url/route.ts
  api/quote/route.ts
  api/contact/route.ts
components/
lib/
public/
  brand/
  media/
_source_assets/
```

## Local setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## Brand assets

Current assets are already placed here:

```txt
public/brand/logo-primary.png
public/brand/logo-icon.png
public/brand/favicon-512.png
public/media/packaging-closed-box-measurements.jpeg
public/media/packaging-flat-dieline.jpeg
public/media/packaging-insert-measurements.jpeg
```

The original filled planning files are preserved in:

```txt
_source_assets/
```

Replace or add final content here when ready:

```txt
public/media/hero-magnet-loop.webm
public/media/hero-magnet-loop.mp4
public/media/magnet-front.png
public/media/magnet-angle.png
public/media/magnet-side.png
public/media/magnet-back.png
public/media/magnet-stack.png
public/media/event-booth-ai.png
public/media/gift-scene-ai.png
public/media/b2b-giveaway-ai.png
public/media/quality-closeup-ai.png
public/media/og-image.png
```

If hero video files are missing, the site uses a Framer Motion animated fallback.

## Pricing

Edit pricing in:

```txt
lib/pricing.ts
```

Current premium launch pricing:

- 1 magnet: $12.99
- 4-pack: $39.99
- 9-pack: $74.99
- 12-pack: $94.99
- 24-pack: $169.99

Event/B2B quote anchors are also in `lib/pricing.ts`.

## Supabase setup

Create a Supabase project, then create a private storage bucket named:

```txt
order-uploads
```

The website uses signed upload URLs so customer photos should not be publicly exposed.

### SQL schema

Run this in Supabase SQL editor:

```sql
create extension if not exists "pgcrypto";

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  stripe_session_id text unique,
  customer_name text,
  customer_email text,
  product_id text,
  quantity integer,
  shape text,
  size text,
  finish text,
  upload_path text,
  notes text,
  amount_total integer,
  currency text,
  status text,
  fulfillment_status text
);

create table if not exists public.quote_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  full_name text,
  email text,
  phone text,
  company text,
  event_type text,
  event_date date,
  city_state text,
  quantity_range text,
  needs_design_help boolean default false,
  message text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  utm_content text,
  utm_term text
);
```

## Stripe setup

1. Create a Stripe account.
2. Add `STRIPE_SECRET_KEY` to `.env.local` and Netlify.
3. Add `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` for future client-side Stripe use.
4. Create a webhook endpoint after deployment:

```txt
https://YOUR-DOMAIN.com/api/stripe-webhook
```

Listen for:

```txt
checkout.session.completed
```

Add the webhook signing secret to:

```txt
STRIPE_WEBHOOK_SECRET
```

The checkout route creates a Stripe Checkout Session and stores important order details in metadata.

## Email notifications

The website is Resend-ready. Add:

```txt
RESEND_API_KEY=
ORDER_NOTIFICATION_EMAIL=snapmagnetusa@gmail.com
```

Current placeholders use senders like `orders@snapmagnetusa.com`. Before enabling Resend, verify your sending domain and update sender addresses in:

```txt
lib/email.ts
```

If Resend is not configured, email sending is skipped safely.

## Analytics and ad tracking

Add these when ready:

```txt
NEXT_PUBLIC_GTM_ID=
NEXT_PUBLIC_GA4_ID=
NEXT_PUBLIC_META_PIXEL_ID=
NEXT_PUBLIC_TIKTOK_PIXEL_ID=
NEXT_PUBLIC_CLARITY_ID=
NEXT_PUBLIC_POSTHOG_KEY=
NEXT_PUBLIC_POSTHOG_HOST=
```

Tracking helpers are in:

```txt
lib/tracking.ts
```

Tracked events include:

- view_item
- upload_started
- upload_completed
- customization_complete
- add_to_cart
- begin_checkout
- purchase
- quote_form_start
- generate_lead
- social_click

## Netlify deployment

1. Push this folder to a GitHub repository.
2. Connect the repository to Netlify.
3. Use build command:

```bash
npm run build
```

4. Publish directory:

```txt
.next
```

5. Netlify plugin is already configured in `netlify.toml`:

```toml
[[plugins]]
  package = "@netlify/plugin-nextjs"
```

6. Add all environment variables in Netlify Site Settings > Environment Variables.
7. Redeploy after adding or changing secrets.

## Demo mode

In local development only, if Stripe/Supabase are not configured:

- Upload URL route returns a demo path.
- Checkout route redirects to `/checkout/success?demo=1`.

In production, missing Stripe/Supabase configuration returns an error instead of silently accepting orders.

## Legal pages

Draft placeholder legal pages are included:

- `/privacy`
- `/terms`
- `/shipping`
- `/refunds`

Review them professionally before running ads or accepting orders.

## Launch checklist

- [ ] Confirm final product size, material, finish, and packaging details.
- [ ] Replace placeholder legal launch dates.
- [ ] Review legal policies.
- [ ] Confirm pricing and shipping rules.
- [ ] Add real product photography and/or AI-generated website visuals.
- [ ] Add optimized hero video files if available.
- [ ] Create Supabase project and private bucket.
- [ ] Run Supabase SQL schema.
- [ ] Add Stripe keys.
- [ ] Add Stripe webhook.
- [ ] Test product upload.
- [ ] Test Stripe checkout.
- [ ] Test webhook order creation.
- [ ] Test quote form.
- [ ] Add analytics IDs.
- [ ] Test Meta/TikTok/GA4 events.
- [ ] Connect custom domain.
- [ ] Complete mobile QA.
- [ ] Remove or update any placeholder copy.
