# Snap Magnet USA — Codespaces Quick Start

Use these steps inside GitHub Codespaces.

## 1. Confirm you are in the project folder

```bash
pwd
ls
```

You should see `package.json`, `app`, `components`, `lib`, and `public`.

## 2. Install dependencies

```bash
npm install
```

Do not type `npm instal` and do not paste `npm install` and `npm run dev` on the same broken line.

## 3. Run the website preview

```bash
npm run dev
```

Codespaces should show port 3000. Click **Open in Browser**.

## 4. Commit the project

```bash
git add .
git commit -m "Initial Snap Magnet USA website"
git push
```

## 5. Deploy on Netlify

Connect this GitHub repo to Netlify. Use:

```text
Build command: npm run build
Publish directory: .next
```

The project includes `netlify.toml` and `@netlify/plugin-nextjs`.

## Important

This cleaned version includes `.gitignore`, so `node_modules`, `.next`, and secrets will not be committed.
