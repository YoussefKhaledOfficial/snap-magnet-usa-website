export type ProductCardData = {
  title: string;
  description: string;
  badge: string;
  cta: string;
  href: string;
};

export const shopPreviewProducts: ProductCardData[] = [
  {
    title: "Custom Photo Magnet",
    description: "Upload one favorite photo and create a personalized magnet made for everyday display.",
    badge: "Personal",
    cta: "Create yours",
    href: "/product/custom-photo-magnet"
  },
  {
    title: "Photo Magnet Packs",
    description: "Create a gift-ready set for family, friends, events, or special memories.",
    badge: "Gift-ready",
    cta: "Build a pack",
    href: "/product/custom-photo-magnet"
  },
  {
    title: "Event Magnet Packages",
    description: "Turn weddings, graduations, birthdays, and private celebrations into take-home keepsakes.",
    badge: "Events",
    cta: "Request pricing",
    href: "/events"
  },
  {
    title: "Business Giveaway Magnets",
    description: "Create branded magnets for expos, QR campaigns, restaurants, schools, nonprofits, and corporate gifts.",
    badge: "B2B",
    cta: "Explore business",
    href: "/b2b"
  }
];

export const shopProducts: ProductCardData[] = [
  ...shopPreviewProducts,
  {
    title: "QR Code Promotional Magnet",
    description: "Turn a QR campaign, menu, review link, or appointment reminder into a premium branded magnet.",
    badge: "Campaign",
    cta: "Get a quote",
    href: "/quote"
  }
];
