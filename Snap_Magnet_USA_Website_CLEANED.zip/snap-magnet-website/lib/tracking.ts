declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
    fbq?: (...args: unknown[]) => void;
    ttq?: { track?: (...args: unknown[]) => void; page?: (...args: unknown[]) => void };
    posthog?: { capture?: (event: string, properties?: Record<string, unknown>) => void };
    clarity?: (...args: unknown[]) => void;
  }
}

type TrackingPayload = Record<string, unknown>;

function push(event: string, payload: TrackingPayload = {}) {
  if (typeof window === "undefined") return;
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event, ...payload });
  window.gtag?.("event", event, payload);
  window.posthog?.capture?.(event, payload);
}

function meta(event: string, payload: TrackingPayload = {}) {
  if (typeof window === "undefined") return;
  window.fbq?.("trackCustom", event, payload);
}

function tiktok(event: string, payload: TrackingPayload = {}) {
  if (typeof window === "undefined") return;
  window.ttq?.track?.(event, payload);
}

export function trackViewItem(payload: TrackingPayload) { push("view_item", payload); meta("ViewItem", payload); tiktok("ViewContent", payload); }
export function trackUploadStarted() { push("upload_started"); }
export function trackUploadCompleted() { push("upload_completed"); }
export function trackCustomizationComplete() { push("customization_complete"); }
export function trackAddToCart(payload: TrackingPayload) { push("add_to_cart", payload); meta("AddToCart", payload); tiktok("AddToCart", payload); }
export function trackBeginCheckout(payload: TrackingPayload) { push("begin_checkout", payload); meta("InitiateCheckout", payload); tiktok("InitiateCheckout", payload); }
export function trackPurchase(payload: TrackingPayload) { push("purchase", payload); meta("Purchase", payload); tiktok("CompletePayment", payload); }
export function trackQuoteFormStart() { push("quote_form_start"); }
export function trackGenerateLead(payload: TrackingPayload = {}) { push("generate_lead", payload); meta("Lead", payload); tiktok("SubmitForm", payload); }
export function trackSocialClick(platform: string) { push("social_click", { platform }); }

export function getUtmParams() {
  if (typeof window === "undefined") {
    return { utmSource: "", utmMedium: "", utmCampaign: "", utmContent: "", utmTerm: "" };
  }
  const params = new URLSearchParams(window.location.search);
  return {
    utmSource: params.get("utm_source") || "",
    utmMedium: params.get("utm_medium") || "",
    utmCampaign: params.get("utm_campaign") || "",
    utmContent: params.get("utm_content") || "",
    utmTerm: params.get("utm_term") || ""
  };
}

export {};
