import { z } from "zod";

export const productBuilderSchema = z.object({
  customerName: z.string().min(2, "Please enter your name."),
  customerEmail: z.string().email("Please enter a valid email."),
  quantity: z.coerce.number().refine((v) => [1, 4, 9, 12, 24].includes(v), "Choose a valid pack size."),
  shape: z.enum(["square", "rectangle", "round"]),
  size: z.string().min(2),
  finish: z.enum(["glossy", "matte"]),
  notes: z.string().max(1000).optional().default("")
});

export type ProductBuilderInput = z.infer<typeof productBuilderSchema>;

export const checkoutRequestSchema = productBuilderSchema.extend({
  productId: z.string().min(1),
  uploadPath: z.string().min(1)
});

export type CheckoutRequestInput = z.infer<typeof checkoutRequestSchema>;

export const uploadRequestSchema = z.object({
  fileName: z.string().min(1),
  contentType: z.string().refine((type) => ["image/jpeg", "image/png", "image/webp"].includes(type), "Only JPG, PNG, and WebP files are allowed.")
});

export const quoteRequestSchema = z.object({
  fullName: z.string().min(2, "Please enter your full name."),
  email: z.string().email("Please enter a valid email."),
  phone: z.string().optional().default(""),
  company: z.string().optional().default(""),
  eventType: z.string().min(2, "Please select or enter an event type."),
  eventDate: z.string().optional().default(""),
  cityState: z.string().min(2, "Please enter the event city/state."),
  quantityRange: z.string().min(2),
  needsDesignHelp: z.coerce.boolean().default(false),
  message: z.string().max(2000).optional().default(""),
  utmSource: z.string().optional().default(""),
  utmMedium: z.string().optional().default(""),
  utmCampaign: z.string().optional().default(""),
  utmContent: z.string().optional().default(""),
  utmTerm: z.string().optional().default("")
});

export type QuoteRequestInput = z.infer<typeof quoteRequestSchema>;
