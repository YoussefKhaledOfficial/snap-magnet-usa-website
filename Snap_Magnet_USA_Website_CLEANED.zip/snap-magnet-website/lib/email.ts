type OrderEmailInput = {
  customerEmail: string;
  customerName: string;
  quantity: number;
  shape: string;
  size: string;
  finish: string;
};

type QuoteEmailInput = {
  fullName: string;
  email: string;
  phone?: string;
  company?: string;
  eventType: string;
  quantityRange: string;
  cityState: string;
  message?: string;
};

async function getResend() {
  if (!process.env.RESEND_API_KEY) return null;
  const { Resend } = await import("resend");
  return new Resend(process.env.RESEND_API_KEY);
}

export async function sendOrderConfirmation(input: OrderEmailInput) {
  const resend = await getResend();
  if (!resend) return { skipped: true };
  return resend.emails.send({
    from: "Snap Magnet USA <orders@snapmagnetusa.com>",
    to: input.customerEmail,
    bcc: process.env.ORDER_NOTIFICATION_EMAIL || "snapmagnetusa@gmail.com",
    subject: "We received your Snap Magnet USA order",
    html: `<p>Hi ${input.customerName},</p><p>Thanks for your order. We received your ${input.quantity}-pack custom magnet order (${input.shape}, ${input.size}, ${input.finish}).</p><p>If we need anything else, we will contact you by email.</p>`
  });
}

export async function sendQuoteNotification(input: QuoteEmailInput) {
  const resend = await getResend();
  if (!resend) return { skipped: true };
  return resend.emails.send({
    from: "Snap Magnet USA <quotes@snapmagnetusa.com>",
    to: process.env.ORDER_NOTIFICATION_EMAIL || "snapmagnetusa@gmail.com",
    replyTo: input.email,
    subject: `New quote request: ${input.eventType}`,
    html: `<h2>New quote request</h2><p><strong>Name:</strong> ${input.fullName}</p><p><strong>Email:</strong> ${input.email}</p><p><strong>Phone:</strong> ${input.phone || ""}</p><p><strong>Company:</strong> ${input.company || ""}</p><p><strong>Event type:</strong> ${input.eventType}</p><p><strong>Quantity:</strong> ${input.quantityRange}</p><p><strong>Location:</strong> ${input.cityState}</p><p><strong>Message:</strong><br/>${input.message || ""}</p>`
  });
}
