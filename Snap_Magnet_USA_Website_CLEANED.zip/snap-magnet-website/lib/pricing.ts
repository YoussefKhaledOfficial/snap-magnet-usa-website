export const QUANTITIES = [1, 4, 9, 12, 24] as const;

export const PACK_PRICES_CENTS: Record<number, number> = {
  1: 1299,
  4: 3999,
  9: 7499,
  12: 9499,
  24: 16999
};

export const EVENT_QUOTE_ANCHORS = [
  { quantity: "50 magnets", price: "$249", unit: "$4.98 each" },
  { quantity: "100 magnets", price: "$449", unit: "$4.49 each" },
  { quantity: "250 magnets", price: "$999", unit: "$4.00 each" },
  { quantity: "500 magnets", price: "$1,749", unit: "$3.50 each" },
  { quantity: "1,000+ magnets", price: "Custom quote", unit: "Volume pricing" }
];

export function getPriceForQuantity(quantity: number) {
  return PACK_PRICES_CENTS[quantity] ?? PACK_PRICES_CENTS[4];
}

export function getUnitPrice(quantity: number) {
  return Math.round(getPriceForQuantity(quantity) / quantity);
}

export function formatMoney(cents: number, currency = "USD") {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
}
